package com.example.contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertEquals(contact, contactService.getContact("1"));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("1");

        assertNull(contactService.getContact("1"));
    }

    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("1", "Jane", "Smith", "0987654321", "456 Elm St");

        Contact updatedContact = contactService.getContact("1");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Elm St", updatedContact.getAddress());
    }

    @Test
    public void testAddDuplicateContact() {
        ContactService contactService = new ContactService();
        Contact contact1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("1", "Jane", "Smith", "0987654321", "456 Elm St");
        contactService.addContact(contact1);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact2);
        });
        assertEquals("Contact ID already exists", exception.getMessage());
    }

    @Test
    public void testUpdateNonexistentContact() {
        ContactService contactService = new ContactService();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("1", "Jane", "Smith", "0987654321", "456 Elm St");
        });
        assertEquals("Contact ID does not exist", exception.getMessage());
    }

    @Test
    public void testAddMultipleContacts() {
        ContactService contactService = new ContactService();
        Contact contact1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("2", "Jane", "Smith", "0987654321", "456 Elm St");

        contactService.addContact(contact1);
        contactService.addContact(contact2);

        assertEquals(contact1, contactService.getContact("1"));
        assertEquals(contact2, contactService.getContact("2"));

        assertNotEquals(contact1, contactService.getContact("2"));
        assertNotEquals(contact2, contactService.getContact("1"));
    }
}
