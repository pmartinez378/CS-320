package test;

import main.Appointment;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60);
        Appointment appointment = new Appointment("12345", futureDate, "Description");
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Description", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Description"));
    }

    @Test
    public void testNullAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Description"));
    }

    @Test
    public void testNullAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", null, "Description"));
    }

    @Test
    public void testPastAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 1000 * 60 * 60);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", pastDate, "Description"));
    }

    @Test
    public void testDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, "A very long description that exceeds the maximum length of fifty characters"));
    }

    @Test
    public void testNullDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, null));
    }
}
