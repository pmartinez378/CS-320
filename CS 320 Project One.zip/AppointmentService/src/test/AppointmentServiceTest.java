package test;

import main.Appointment;
import main.AppointmentService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 1000 * 60 * 60), "Description");
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("12345"));
    }

    @Test
    public void testAddDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();
        Appointment appointment1 = new Appointment("12345", new Date(System.currentTimeMillis() + 1000 * 60 * 60), "Description");
        Appointment appointment2 = new Appointment("12345", new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 2), "Description2");
        service.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment2));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 1000 * 60 * 60), "Description");
        service.addAppointment(appointment);
        service.deleteAppointment("12345");
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment("12345"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("nonexistent"));
    }
}
