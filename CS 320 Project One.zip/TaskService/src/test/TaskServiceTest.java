package test;

import main.Task;
import main.TaskService;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("1", "Task Name", "Task Description");
        taskService.addTask(task);

        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    public void testDeleteTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("1", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.deleteTask("1");

        assertNull(taskService.getTask("1"));
    }

    @Test
    public void testUpdateTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("1", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.updateTask("1", "New Name", "New Description");

        Task updatedTask = taskService.getTask("1");
        assertEquals("New Name", updatedTask.getName());
        assertEquals("New Description", updatedTask.getDescription());
    }

    @Test
    public void testAddDuplicateTask() {
        TaskService taskService = new TaskService();
        Task task1 = new Task("1", "Task Name", "Task Description");
        Task task2 = new Task("1", "Another Name", "Another Description");
        taskService.addTask(task1);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task2);
        });
        assertEquals("Task ID already exists", exception.getMessage());
    }

    @Test
    public void testUpdateNonexistentTask() {
        TaskService taskService = new TaskService();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("1", "New Name", "New Description");
        });
        assertEquals("Task ID does not exist", exception.getMessage());
    }

    @Test
    public void testAddMultipleTasks() {
        TaskService taskService = new TaskService();
        Task task1 = new Task("1", "Task Name", "Task Description");
        Task task2 = new Task("2", "Another Name", "Another Description");

        taskService.addTask(task1);
        taskService.addTask(task2);

        assertEquals(task1, taskService.getTask("1"));
        assertEquals(task2, taskService.getTask("2"));

        assertNotEquals(task1, taskService.getTask("2"));
        assertNotEquals(task2, taskService.getTask("1"));
    }

    @Test
    public void testUpdateMultipleTasks() {
        TaskService taskService = new TaskService();
        Task task1 = new Task("1", "Task Name", "Task Description");
        Task task2 = new Task("2", "Another Name", "Another Description");

        taskService.addTask(task1);
        taskService.addTask(task2);

        taskService.updateTask("1", "Updated Name 1", "Updated Description 1");
        taskService.updateTask("2", "Updated Name 2", "Updated Description 2");

        Task updatedTask1 = taskService.getTask("1");
        Task updatedTask2 = taskService.getTask("2");

        assertEquals("Updated Name 1", updatedTask1.getName());
        assertEquals("Updated Description 1", updatedTask1.getDescription());

        assertEquals("Updated Name 2", updatedTask2.getName());
        assertEquals("Updated Description 2", updatedTask2.getDescription());
    }

    @Test
    public void testDeleteMultipleTasks() {
        TaskService taskService = new TaskService();
        Task task1 = new Task("1", "Task Name", "Task Description");
        Task task2 = new Task("2", "Another Name", "Another Description");

        taskService.addTask(task1);
        taskService.addTask(task2);

        taskService.deleteTask("1");
        taskService.deleteTask("2");

        assertNull(taskService.getTask("1"));
        assertNull(taskService.getTask("2"));
    }
}
