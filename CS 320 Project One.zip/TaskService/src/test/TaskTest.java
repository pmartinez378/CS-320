package test;

import main.Task;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("1", "Task Name", "Task Description");
        assertEquals("1", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "Task Description");
        });
        assertEquals("Invalid task ID", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "Task Description");
        });
        assertEquals("Invalid task ID", exception.getMessage());
    }

    @Test
    public void testInvalidName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", null, "Task Description");
        });
        assertEquals("Invalid task name", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "This name is too long", "Task Description");
        });
        assertEquals("Invalid task name", exception.getMessage());
    }

    @Test
    public void testInvalidDescription() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Task Name", null);
        });
        assertEquals("Invalid task description", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Task Name", "This description is way too long and exceeds the 50 character limit.");
        });
        assertEquals("Invalid task description", exception.getMessage());
    }

    @Test
    public void testTaskIdImmutability() {
        Task task = new Task("1", "Task Name", "Task Description");
        String originalTaskId = task.getTaskId();

        Exception exception = assertThrows(UnsupportedOperationException.class, () -> {
            throw new UnsupportedOperationException("Task ID cannot be changed");
        });

        assertEquals("Task ID cannot be changed", exception.getMessage());
        assertEquals(originalTaskId, task.getTaskId());
    }
}
